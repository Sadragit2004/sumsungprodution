$(document).on('change', 'select[id^="id_features_value-"][id$="-feature"]', function() {
    var featureId = $(this).val();
    var currentId = $(this).attr('id');
    var filterValueId = currentId.replace("-feature", "-filterValue");

    console.log('🚀 Feature changed - Feature ID:', featureId);
    console.log('🔍 Current ID:', currentId);
    console.log('🎯 Filter Value ID:', filterValueId);

    if (!featureId) {
        console.log('❌ No feature selected');
        $('#' + filterValueId).empty().append('<option value="">---------</option>');
        return;
    }

    $.ajax({
        type: "GET",
        url: "/product/f/ajax_admin/?feature_id=" + featureId,
        success: function(response) {
            console.log('✅ AJAX Success - Response:', response);

            var $filterSelect = $('#' + filterValueId);
            console.log('🔍 Filter select element:', $filterSelect);
            console.log('🔍 Filter select length:', $filterSelect.length);

            $filterSelect.empty().append('<option value="">---------</option>');

            if (response && typeof response === 'object') {
                console.log('📝 Adding options to dropdown...');
                var optionCount = 0;

                $.each(response, function(key, value) {
                    console.log('➕ Adding option:', key, '->', value);
                    $filterSelect.append($('<option>', {
                        value: value,
                        text: key
                    }));
                    optionCount++;
                });

                console.log('✅ Total options added:', optionCount);
            } else {
                console.warn('⚠️ Unexpected response format:', response);
            }

            // تست: آیا options اضافه شده‌اند؟
            console.log('🔢 Final options count:', $filterSelect.find('option').length);
            console.log('📋 Final options:', $filterSelect.find('option').map(function() {
                return $(this).text() + ':' + $(this).val();
            }).get());
        },
        error: function(xhr, status, error) {
            console.error('❌ AJAX Error:', error);
            console.log('📊 Status:', status);
            console.log('📄 Response Text:', xhr.responseText);
            $('#' + filterValueId).empty().append('<option value="">---------</option>');
        }
    });
});